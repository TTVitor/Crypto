const Money = require('../models/Money')

module.exports = class MoneyController {
  static loginMoney(req, res) {
    res.render('crypto/login', { layout: 'user' })
  }

  static registerMoney(req, res) {
    res.render('crypto/register', { layout: 'user' })
  }

  static indexMoney(req, res) {
    res.render('crypto/index', { layout: 'admin' })
  }

  static dashboardMoney(req, res) {
    res.render('crypto/dashboard', { layout: 'admin' })
  }

  static faqMoney(req, res) {
    res.render('crypto/faq', { layout: 'admin' })
  }

  static buyMoney(req, res) {
    res.render('crypto/buy', { layout: 'admin' })
  }

  static transactionsMoney(req, res) {
    res.render('crypto/transactions', { layout: 'admin' })
  }

  static walletMoney(req, res) {
    res.render('crypto/wallet', { layout: 'admin' })
  }

    static changeStatus(req, res) {
        const id = req.body.id
    
        console.log(req.body)
    
        const money = {
          status: req.body.status === '0' ? true : false,
        }
    
        console.log(money)
    
        Money.update(money, { where: { id: id } })
          .then(res.redirect('/money'))
          .catch((err) => console.log())
    }
}