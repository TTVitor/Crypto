const User = require('../models/User')

module.exports = class UserController {
  static createUser(req, res) {
    res.render('user/create')
  }

  static createUserSave(req, res) {
    const user = {
      usuario: req.body.usuario,
      email: req.body.email,
    }

   User.create(user)
      .then(res.redirect('/user'))
      .catch((err) => console.log())
  }

  static showUser(req, res) {
    User.findAll({ raw: true })
      .then((data) => {
        let emptyUser = false

        if (data.length === 0) {
          emptyUser = true
        }

        res.render('crypto/register', { user: data, emptyUser, layout: 'user' })
      })
      .catch((err) => console.log(err))
  }

  static loginUser(req, res) {
    res.render('crypto/login', { layout: 'user' })
  }
}
