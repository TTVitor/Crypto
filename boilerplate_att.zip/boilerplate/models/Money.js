const { DataTypes } = require('sequelize')

const db = require('../db/conn')

const Money = db.define('Money', {
  status: {
    type: DataTypes.BOOLEAN,
  },
})

module.exports = Money