const express = require('express')
const router = express.Router()
const MoneyController = require('../controllers/MoneyController')

router.get('/login', MoneyController.loginMoney)
router.get('/register', MoneyController.registerMoney)
router.get('/index', MoneyController.indexMoney)
router.get('/dashboard', MoneyController.dashboardMoney)
router.get('/faq', MoneyController.faqMoney)
router.get('/buy', MoneyController.buyMoney)
router.get('/transactions', MoneyController.transactionsMoney)
router.get('/wallet', MoneyController.walletMoney)
router.post('/updatestatus', MoneyController.changeStatus)

module.exports = router