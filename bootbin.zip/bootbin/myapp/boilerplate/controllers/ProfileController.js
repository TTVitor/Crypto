const Profile = require('../models/Profile')

module.exports = class ProfileController {
  static createProfile(req, res) {
    res.render('profile/create')
  }

  static createProfileSave(req, res) {
    const profile = {
      usuario: req.body.usuario,
      senha: req.body.senha,
    }

   Profile.create(profile)
      .then(res.redirect('/profile'))
      .catch((err) => console.log())
    }

  static showProfile(req, res) {
    Profile.findAll({ raw: true })
      .then((data) => {
        let emptyProfile = false

        if (data.length === 0) {
          emptyProfile = true
        }

        res.render('crypto/profile', { user: data, emptyProfile, layout: 'admin' })
      })
      .catch((err) => console.log(err))
    }

    static loginProfile(req, res) {
      res.render('crypto/login', { layout: 'user' })
    }

    static registerProfile(req, res) {
      res.render('crypto/register', { layout: 'user' })
    }

    static indexProfile(req, res) {
      res.render('crypto/index', { layout: 'admin' })
    }

    static dashboardProfile(req, res) {
      res.render('crypto/dashboard', { layout: 'admin' })
    }

    static faqProfile(req, res) {
      res.render('crypto/faq', { layout: 'admin' })
    }

    static buyProfile(req, res) {
      res.render('crypto/buy', { layout: 'admin' })
    }

    static transactionsProfile(req, res) {
      res.render('crypto/transactions', { layout: 'admin' })
    }

    static walletProfile(req, res) {
      res.render('crypto/wallet', { layout: 'admin' })
    }

    static historyProfile(req, res) {
      res.render('crypto/history', { layout: 'admin' })
    }

  static removeProfile(req, res) {
    const id = req.body.id

    Profile.destroy({ where: { id: id } })
      .then(res.redirect('/profile'))
      .catch((err) => console.log())
    }

  static updateProfile(req, res) {
    const id = req.params.id

    Profile.findOne({ where: { id: id }, raw: true })
      .then((data) => {
        res.render('profile/edit', { profile: data })
      })
      .catch((err) => console.log())
    }

  static updateProfilePost(req, res) {
    const id = req.body.id

    const profile = {
      nome: req.body.nome,
      sobrenome: req.body.sobrenome,
      usuario: req.body.usuario,
      email: req.body.email,
      senha: req.body.senha,
      novasenha: req.body.novasenha,
    }

    Profile.update(profile, { where: { id: id } })
      .then(res.redirect('/profile'))
      .catch((err) => console.log())
    }
}