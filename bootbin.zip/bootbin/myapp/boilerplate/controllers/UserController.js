const User = require('../models/User')

module.exports = class UserController {
  static createUser(req, res) {
    res.render('crypto/create', { layout: 'user' })
  }

  static createUserSave(req, res) {
    // console.log('@@' + req.body.usuario)
    // console.log('@@' + req.body.email)
    // console.log('@@' + req.body.senha)
    const user = {
      usuario: req.body.usuario,
      email: req.body.email,
      senha: req.body.senha,
    }

  
   User.create(user)
      .then(res.redirect('/user/login'))
      .catch((err) => console.log())
  
  }

  static showUser(req, res) {
    User.findAll({ raw: true })
      .then((data) => {
        let emptyUser = false

        if (data.length === 0) {
          emptyUser = true
        }

        res.render('crypto/register', { user: data, emptyUser, layout: 'user' })
      })
      .catch((err) => console.log(err))
  }

  static loginUser(req, res) {
    res.render('crypto/login', { layout: 'user' })
  }
}
