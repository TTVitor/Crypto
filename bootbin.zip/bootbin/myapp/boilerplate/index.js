const express = require('express')
const exphbs = require('express-handlebars')

const app = express()

const conn = require('./db/conn')

const User = require('./models/User')
const Profile = require('./models/Profile')
//const Money = require('./models/Money')

const userRoutes = require('./routes/userRoutes')
const profileRoutes = require('./routes/profileRoutes')
//const moneyRoutes = require('./routes/moneyRoutes')

app.engine('handlebars', exphbs())
app.set('view engine', 'handlebars')

app.use(
  express.urlencoded({
    extended: true,
  }),
)

app.use(express.json())

app.use(express.static('public'))

app.use('/user', userRoutes)
app.use('/profile', profileRoutes)
//app.use('/money', moneyRoutes)


conn
  .sync()
  .then(() => {
    app.listen(3000)
  })
  .catch((err) => console.log(err))
