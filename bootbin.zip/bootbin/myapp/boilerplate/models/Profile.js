const { DataTypes } = require('sequelize')

const db = require('../db/conn')

const Profile = db.define('Profile', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    sobrenome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    usuario: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  senha: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  novasenha: {
    type: DataTypes.STRING,
    allowNull: true,
  },
})

module.exports = Profile