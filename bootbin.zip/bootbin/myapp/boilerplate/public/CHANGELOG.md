# CryptoDash - Free Cryptocurrency Dashboard Template

V1.0 : [20-08-2021] :  Initial Release