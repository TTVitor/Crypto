/*=========================================================================================
	File Name: documentation.js
	Description: Theme documentation js file
	----------------------------------------------------------------------------------------
	Item Name: CryptoDash - Free Cryptocurrency Dashboard Template
	Version: 1.0
	Author: ThemeSelection
	Author URL: https://themeselection.com/
==========================================================================================*/

$(document).ready(function(){
   $('body').scrollspy({ target: '#sidebar-page-navigation' });
});