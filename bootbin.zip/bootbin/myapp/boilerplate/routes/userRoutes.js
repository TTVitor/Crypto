const express = require('express')
const router = express.Router()
const UserController = require('../controllers/UserController')

router.get('/create', UserController.createUser)
router.post('/create', UserController.createUserSave)
router.get('/', UserController.showUser)
router.get('/register', UserController.showUser)
router.get('/login', UserController.loginUser)

module.exports = router
